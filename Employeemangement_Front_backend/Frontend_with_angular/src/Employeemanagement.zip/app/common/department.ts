export class Department {

    constructor(public deptno:number,public dname:string,public loc:string){}
}
