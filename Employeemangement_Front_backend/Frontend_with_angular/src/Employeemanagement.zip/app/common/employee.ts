export class Employee {

  
      constructor(
        public empno : number,
        public ename : string,
        public job : string,
        public hireDate :Date,
        public managerId : number,
        public salary:number,
        public commission : number,
        public deptNo : number
        )
   {} 
    
}
